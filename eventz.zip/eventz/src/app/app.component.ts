import { Component,OnInit, Inject, ViewContainerRef } from '@angular/core';
import { Router, RouterModule}  from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { AgmCoreModule } from '@agm/core';

declare let swal: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  model: any = {};
  chooseparti:any= [];

  lat: number = 11.019194;
  lng: number = 76.970519;


  constructor(public toastr: ToastsManager, vcr: ViewContainerRef) {
    this.toastr.setRootViewContainerRef(vcr);
 }

  addevent()
  {
    this.model.chooseparticipant = this.chooseparti; 

    //Service call to backend to insert to database code here

    console.log(this.model);
    this.toastr.success('Event Registered Successfully!', 'Success!');
  }

  eventchange(event:any)//Checkbox select value stored
  {
    if(this.chooseparti!="")
    {
      var count=0;
      var chkdata=0;
      this.chooseparti.filter((data:any) =>{

        if(data==event)
        {
          chkdata=1;
          return this.chooseparti.splice(count,1);
        }
        count++;
        
      });
      if(chkdata==0)
      {
        this.chooseparti.push(event);
      }
    }
    else
    {  
      this.chooseparti.push(event);
      
    }
    
  }

}
